import base64
import re
from PIL import Image
from openai import OpenAI

# Initialize OpenAI client
client = OpenAI(api_key="OPEN-AI-KEY")  # Replace with your actual API key

# Base64 encoding for image (optional)
def encode_image_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")

# Infer metadata from filename
def infer_from_filename(filename):
    name = filename.lower()
    artist = filename.split('_')[0].replace('-', ' ').title()
    if 'landscape' in name:
        genre = "Landscape"
    elif 'portrait' in name:
        genre = "Portrait"
    elif 'still' in name:
        genre = "Still Life"
    else:
        genre = "Unknown"
    return artist, "Impressionism", genre

# Main generation function
def generate_caption_and_story(image_path, filename, audience='general', include_image=False):
    artist, style, genre = infer_from_filename(filename)
    base64_image = encode_image_to_base64(image_path) if include_image else None

    # Prompt definitions
    audience_prompts = {
        'general': f"This is a painting by {artist} in the {style} style. It depicts a {genre.lower()} scene. "
                   f"First, describe the painting in 2-3 sentences. Then, write a short story inspired by it. "
                   f"Use this format:\n\nDescription: ...\n\nStory: ...",
        'child': f"This painting was made by {artist}. It shows a {genre.lower()} in a fun and colorful style called {style}. "
                 f"First, describe it simply. Then, tell a short, imaginative story. Use this format:\n\nDescription: ...\n\nStory: ...",
        'expert': f"As an art historian, analyze this {genre.lower()} painting by {artist} in the {style} tradition. "
                  f"Then, offer a story that might be told within or about the painting. Use this format:\n\nDescription: ...\n\nStory: ..."
    }

    prompt = audience_prompts.get(audience, audience_prompts['general'])

    # Create messages
    if include_image:
        messages = [
            {"role": "system", "content": "You are an expert in art history and creative writing."},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image}",
                            "detail": "high"
                        }
                    }
                ]
            }
        ]
    else:
        messages = [
            {"role": "system", "content": "You are an expert in art history and creative writing."},
            {"role": "user", "content": prompt}
        ]

    # Call GPT-4o
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=messages,
        temperature=0.8,
        max_tokens=700
    )

    result = response.choices[0].message.content.strip()
    result = re.sub(r'\s+', ' ', result)  # Normalize whitespace

    # Extract caption and story from the formatted output
    caption, story = "", ""
    match = re.search(r"Description:\s*(.*?)\s*Story:\s*(.*)", result, re.IGNORECASE | re.DOTALL)
    if match:
        caption = match.group(1).strip()
        story = match.group(2).strip()
    else:
        # fallback in case GPT-4o does not follow format
        caption = result
        story = ""

    return artist, style, genre, caption, story